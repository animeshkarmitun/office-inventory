@extends('layouts.app')

@section('content')
    <h1>Admin Dashboard</h1>
    <p>Welcome to the admin dashboard. Here you can manage users, assets, and more.</p>
@endsection 