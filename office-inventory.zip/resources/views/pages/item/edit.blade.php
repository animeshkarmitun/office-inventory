@extends('layouts.app')

@section('content')
@include('inc.alert')
<div class="container-fluid px-4 py-4">
    <!-- Modern Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h2 fw-bold text-dark mb-2">Edit Item</h1>
                    <p class="text-muted mb-0">Update inventory item information and details</p>
                </div>
                <a href="{{ route('item') }}" class="btn btn-outline-secondary d-flex align-items-center">
                    <i class="fas fa-arrow-left me-2"></i>
                    Back to Items
                </a>
            </div>
        </div>
    </div>

    {{-- Error summary --}}
    @if ($errors->any())
        <div class="alert alert-danger border-0 shadow-sm mb-4">
            <div class="d-flex align-items-center">
                <i class="fas fa-exclamation-triangle me-3 text-danger"></i>
                <div>
            <strong>There were some problems with your submission:</strong>
                    <ul class="mb-0 mt-2">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
                </div>
            </div>
        </div>
    @endif

    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
        <form action="{{ route('item.update', ['id' => $item->id]) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-primary mb-0 d-flex align-items-center">
                                <i class="fas fa-info-circle me-2"></i>
                                Basic Information
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                    <div class="mb-3">
                        <label for="name" class="form-label">Item Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" required value="{{ old('name', $item->name) }}">
                        @error('name')
                            <div class="invalid-feedback">Item Name is required. Please enter a value.</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="serial_number" class="form-label">Serial Number</label>
                        <input type="text" name="serial_number" class="form-control @error('serial_number') is-invalid @enderror" id="serial_number" value="{{ old('serial_number', $item->serial_number) }}" readonly placeholder="Will be auto-generated">
                        <small class="form-text text-muted">Serial number will be automatically generated when the item is created.</small>
                        @error('serial_number')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="asset_tag" class="form-label">Asset Tag</label>
                        <input type="text" name="asset_tag" class="form-control @error('asset_tag') is-invalid @enderror" id="asset_tag" value="{{ old('asset_tag', $item->asset_tag) }}" readonly placeholder="Will be auto-generated">
                        <small class="form-text text-muted">Asset tag will be automatically generated when the item is created.</small>
                        @error('asset_tag')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="barcode" class="form-label">Barcode</label>
                        <input type="text" name="barcode" class="form-control @error('barcode') is-invalid @enderror" id="barcode" value="{{ old('barcode', $item->barcode) }}">
                        @error('barcode')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="rfid_tag" class="form-label">RFID Tag</label>
                        <input type="text" name="rfid_tag" class="form-control @error('rfid_tag') is-invalid @enderror" id="rfid_tag" value="{{ old('rfid_tag', $item->rfid_tag) }}">
                        @error('rfid_tag')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" class="form-control @error('description') is-invalid @enderror" id="description" rows="3">{{ old('description', $item->description) }}</textarea>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-success mb-0 d-flex align-items-center">
                                <i class="fas fa-cube me-2"></i>
                                Asset Details
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                    <div class="mb-3">
                        <label for="asset_type" class="form-label">Asset Type <span class="text-danger">*</span></label>
                        <select name="asset_type" class="form-select @error('asset_type') is-invalid @enderror" id="asset_type" required>
                            <option value="fixed" {{ old('asset_type', $item->asset_type) == 'fixed' ? 'selected' : '' }}>Fixed Asset</option>
                            <option value="current" {{ old('asset_type', $item->asset_type) == 'current' ? 'selected' : '' }}>Current Asset</option>
                        </select>
                        @error('asset_type')
                            <div class="invalid-feedback">Asset Type is required. Please select a value.</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="value" class="form-label">Value</label>
                        <input type="number" step="0.01" name="value" class="form-control @error('value') is-invalid @enderror" id="value" value="{{ old('value', $item->value) }}">
                        @error('value')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="depreciation_method" class="form-label">Depreciation Method</label>
                        <select name="depreciation_method" class="form-select @error('depreciation_method') is-invalid @enderror" id="depreciation_method">
                            <option value="straight_line" {{ old('depreciation_method', $item->depreciation_method ?: 'straight_line') == 'straight_line' ? 'selected' : '' }}>Straight Line</option>
                            <option value="reducing_balance" {{ old('depreciation_method', $item->depreciation_method) == 'reducing_balance' ? 'selected' : '' }}>Reducing Balance</option>
                        </select>
                        @error('depreciation_method')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="depreciation_rate" class="form-label">Depreciation Rate (%)</label>
                        <input type="number" step="0.01" name="depreciation_rate" class="form-control @error('depreciation_rate') is-invalid @enderror" id="depreciation_rate" value="{{ old('depreciation_rate', $item->depreciation_rate) }}">
                        <small class="form-text text-muted" id="depreciation-note" style="display: none;"></small>
                        @error('depreciation_rate')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select @error('status') is-invalid @enderror" id="status" required>
                            <option value="available" {{ old('status', $item->status) == 'available' ? 'selected' : '' }}>Available</option>
                            <option value="in_use" {{ old('status', $item->status) == 'in_use' ? 'selected' : '' }}>In Use</option>
                            <option value="maintenance" {{ old('status', $item->status) == 'maintenance' ? 'selected' : '' }}>Maintenance</option>
                            <option value="not_traceable" {{ old('status', $item->status) == 'not_traceable' ? 'selected' : '' }}>Not Traceable</option>
                            <option value="disposed" {{ old('status', $item->status) == 'disposed' ? 'selected' : '' }}>Disposed</option>
                        </select>
                        @error('status')
                            <div class="invalid-feedback">Status is required. Please select a value.</div>
                        @enderror
                    </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mt-2">
                <div class="col-lg-6">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-warning mb-0 d-flex align-items-center">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Purchase Information
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                    <div class="mb-3">
                        <label for="purchased_by" class="form-label">Purchased By</label>
                        <select name="purchased_by" class="form-select @error('purchased_by') is-invalid @enderror" id="purchased_by">
                            <option value="">-- Select User --</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ old('purchased_by', $item->purchased_by) == $user->id ? 'selected' : '' }}>{{ $user->name ?? 'No Name' }}</option>
                            @endforeach
                        </select>
                        @error('purchased_by')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="supplier_id" class="form-label">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select @error('supplier_id') is-invalid @enderror" id="supplier_id" required>
                            <option value="">-- Select Supplier --</option>
                            @foreach($suppliers as $supplier)
                                <option value="{{ $supplier->id }}" {{ old('supplier_id', $item->supplier_id ?? $defaultSupplier->id) == $supplier->id ? 'selected' : '' }}>{{ $supplier->name ?? 'No Name' }}</option>
                            @endforeach
                        </select>
                        <small class="form-text text-muted">Default Supplier is pre-selected. You can change it to the actual supplier if needed.</small>
                        @error('supplier_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="purchase_date" class="form-label">Purchase Date</label>
                        <input type="date" name="purchase_date" class="form-control @error('purchase_date') is-invalid @enderror" id="purchase_date" value="{{ old('purchase_date', $item->purchase_date ? $item->purchase_date->format('Y-m-d') : '') }}">
                        @error('purchase_date')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="received_by" class="form-label">Received By</label>
                        <select name="received_by" class="form-select @error('received_by') is-invalid @enderror" id="received_by">
                            <option value="">-- Select User --</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ old('received_by', $item->received_by) == $user->id ? 'selected' : '' }}>{{ $user->name ?? 'No Name' }}</option>
                            @endforeach
                        </select>
                        @error('received_by')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-info mb-0 d-flex align-items-center">
                                <i class="fas fa-map-marker-alt me-2"></i>
                                Location Information
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                    <div class="mb-3">
                        <label for="floor_level" class="form-label">Floor Level <span class="text-danger">*</span></label>
                        <select name="floor_level" class="form-select @error('floor_level') is-invalid @enderror" id="floor_level" required>
                            <option value="">-- Select Floor --</option>
                            @foreach($floors as $floor)
                                <option value="{{ $floor->name }}" {{ old('floor_level', $item->floor_level) == $floor->name ? 'selected' : '' }}>
                                    {{ $floor->name }} ({{ $floor->serial_number }})
                                </option>
                            @endforeach
                        </select>
                        @error('floor_level')
                            <div class="invalid-feedback">Floor Level is required. Please select a value.</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="room_number" class="form-label">Room Number <span class="text-danger">*</span></label>
                        <select name="room_number" class="form-select @error('room_number') is-invalid @enderror" id="room_number" required>
                            <option value="">-- Select Room --</option>
                            @foreach($rooms as $room)
                                <option value="{{ $room->name }}" {{ old('room_number', $item->room_number) == $room->name ? 'selected' : '' }}>
                                    {{ $room->name }} ({{ $room->room_number }}) - {{ $room->floor->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('room_number')
                            <div class="invalid-feedback">Room Number is required. Please select a value.</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Additional Location Details</label>
                        <input type="text" name="location" class="form-control @error('location') is-invalid @enderror" id="location" value="{{ old('location', $item->location) }}">
                        @error('location')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="assigned_to" class="form-label">Assigned To</label>
                        <select name="assigned_to" class="form-select @error('assigned_to') is-invalid @enderror" id="assigned_to">
                            <option value="">-- Select User --</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ old('assigned_to', $item->assigned_to) == $user->id ? 'selected' : '' }}>{{ $user->name ?? 'No Name' }}</option>
                            @endforeach
                        </select>
                        @error('assigned_to')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mt-2">
                <div class="col-12">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-secondary mb-0 d-flex align-items-center">
                                <i class="fas fa-cogs me-2"></i>
                                Specifications & Additional Details
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                    <div class="mb-3">
                        <label for="specifications" class="form-label">Specifications</label>
                        <textarea name="specifications" class="form-control @error('specifications') is-invalid @enderror" id="specifications" rows="3">{{ old('specifications', $item->specifications) }}</textarea>
                        @error('specifications')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

                    <div class="mb-3">
                                <label for="remarks" class="form-label fw-semibold">Remarks</label>
                                <textarea name="remarks" class="form-control @error('remarks') is-invalid @enderror" id="remarks" rows="3" placeholder="Enter any additional remarks...">{{ old('remarks', $item->remarks) }}</textarea>
                        @error('remarks')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mt-2">
                <div class="col-12">
                    <div class="card border-0 bg-light">
                        <div class="card-header bg-transparent border-0 pb-0">
                            <h4 class="fw-bold text-dark mb-0 d-flex align-items-center">
                                <i class="fas fa-image me-2"></i>
                                Item Images
                            </h4>
                        </div>
                        <div class="card-body pt-3">
                            <!-- Current Images Display -->
                            @if($item->images && $item->images->count() > 0)
                                <div class="mb-4">
                                    <h6 class="text-muted mb-3">Current Images:</h6>
                                    <div class="row">
                                        @foreach($item->images as $image)
                                            <div class="col-md-3 mb-3">
                                                <div class="card position-relative">
                                                    <div class="card-img-top" style="height: 150px; overflow: hidden;">
                                                        @if($image->image_path && file_exists(storage_path('app/public/' . $image->image_path)))
                                                            <img src="{{ asset('storage/' . $image->image_path) }}" 
                                                                 alt="Item Image" 
                                                                 class="img-fluid" 
                                                                 style="width: 100%; height: 100%; object-fit: cover;">
                                                        @else
                                                            <div class="bg-light d-flex align-items-center justify-content-center h-100">
                                                                <i class="fas fa-image fa-2x text-muted"></i>
                                                            </div>
                                                        @endif
                                                    </div>
                                                    <div class="card-body p-2">
                                                        <div class="d-flex justify-content-center">
                                                            <button type="button" 
                                                                    class="btn btn-sm btn-outline-danger remove-image-btn" 
                                                                    data-image-id="{{ $image->id }}"
                                                                    data-image-name="{{ $image->original_name }}"
                                                                    title="Remove this image">
                                                                <i class="fas fa-trash"></i> Remove
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @elseif($item->image)
                                <div class="mb-4">
                                    <h6 class="text-muted mb-3">Current Image:</h6>
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <div class="card position-relative">
                                                <div class="card-img-top" style="height: 150px; overflow: hidden;">
                                                    @if($item->image && file_exists(storage_path('app/public/' . $item->image)))
                                                        <img src="{{ asset('storage/' . $item->image) }}" 
                                                             alt="Item Image" 
                                                             class="img-fluid" 
                                                             style="width: 100%; height: 100%; object-fit: cover;">
                                                    @else
                                                        <div class="bg-light d-flex align-items-center justify-content-center h-100">
                                                            <i class="fas fa-image fa-2x text-muted"></i>
                                                        </div>
                                                    @endif
                                                </div>
                                                <div class="card-body p-2">
                                                    <div class="d-flex justify-content-center">
                                                        <button type="button" 
                                                                class="btn btn-sm btn-outline-danger remove-legacy-image-btn" 
                                                                data-item-id="{{ $item->id }}"
                                                                title="Remove legacy image">
                                                            <i class="fas fa-trash"></i> Remove
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif

                            <!-- New Images Upload -->
                            <div class="mb-3">
                                <label for="images" class="form-label fw-semibold">Upload New Images</label>
                                <input type="file" name="images[]" id="images" class="form-control @error('images') is-invalid @enderror" accept="image/*" multiple>
                                <small class="form-text text-muted">Supported formats: JPG, PNG, GIF, WEBP (Max 10MB per image, Multiple images allowed)</small>
                                @error('images')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                @error('images.*')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                
                                <!-- Image Preview Container -->
                                <div id="imagePreview" class="mt-3" style="display: none;">
                                    <h6 class="text-muted mb-2">Selected Images:</h6>
                                    <div id="imagePreviewContainer" class="row"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex justify-content-end gap-3">
                        <a href="{{ route('item') }}" class="btn btn-outline-secondary px-4">
                            <i class="fas fa-times me-2"></i>
                            Cancel
                        </a>
                        <button type="submit" class="btn btn-primary px-5 d-flex align-items-center">
                            <i class="fas fa-save me-2"></i>
                            Update Item
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

@push('styles')
<style>
    .card {
        transition: all 0.3s ease;
        border-radius: 12px;
    }
    
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1) !important;
    }
    
    .form-control, .form-select {
        border-radius: 8px;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        transform: translateY(-1px);
    }
    
    .btn {
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn:hover {
        transform: translateY(-1px);
    }
    
    .form-label {
        color: #495057;
        margin-bottom: 8px;
    }
    
    .text-muted {
        font-size: 0.875rem;
    }
    
    .bg-light {
        background-color: #f8f9fa !important;
    }
    
    .fw-semibold {
        font-weight: 600 !important;
    }
    
    .h2 {
        font-size: 2rem;
    }
    
    .card-header h4 {
        font-size: 1.1rem;
    }
    
    .btn-outline-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
    }
    
    .btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(13, 110, 253, 0.4);
    }
    
    .alert {
        border-radius: 8px;
        border: none;
    }
</style>
@endpush

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-calculate depreciation cost
        const valueField = document.getElementById('value');
        const depreciationRateField = document.getElementById('depreciation_rate');
        
        function calculateDepreciationCost() {
            const value = parseFloat(valueField.value) || 0;
            const rate = parseFloat(depreciationRateField.value) || 0;
            const depreciationCost = (value * rate) / 100;
            
            const depreciationNote = document.getElementById('depreciation-note');
            if (depreciationNote) {
                if (value > 0 && rate > 0) {
                    depreciationNote.textContent = `Depreciation cost will be automatically calculated: $${depreciationCost.toFixed(2)}`;
                    depreciationNote.style.display = 'block';
                } else {
                    depreciationNote.style.display = 'none';
                }
            }
        }
        
        valueField.addEventListener('input', calculateDepreciationCost);
        depreciationRateField.addEventListener('input', calculateDepreciationCost);
        
        // Run calculation on page load
        calculateDepreciationCost();

        // Room filtering functionality
        const floorSelect = document.getElementById('floor_level');
        const roomSelect = document.getElementById('room_number');
        
        // Store all rooms data for filtering
        const allRooms = [
            @foreach($rooms as $room)
            {
                id: {{ $room->id }},
                name: "{{ $room->name }}",
                room_number: "{{ $room->room_number }}",
                floor_name: "{{ $room->floor->name }}",
                floor_id: {{ $room->floor_id }}
            }@if(!$loop->last),@endif
            @endforeach
        ];

        // Function to filter rooms based on selected floor
        function filterRoomsByFloor(selectedFloorName) {
            // Get current room selection before clearing
            const currentRoomValue = roomSelect.value;
            
            // Clear current room options except the first one
            roomSelect.innerHTML = '<option value="">-- Select Room --</option>';
            
            if (!selectedFloorName) {
                // Show all rooms if no floor is selected
                allRooms.forEach(room => {
                    const option = document.createElement('option');
                    option.value = room.name;
                    option.textContent = `${room.name} (${room.room_number}) - ${room.floor_name}`;
                    if (room.name === currentRoomValue) {
                        option.selected = true;
                    }
                    roomSelect.appendChild(option);
                });
                return;
            }
            
            // Filter rooms that belong to the selected floor
            const filteredRooms = allRooms.filter(room => room.floor_name === selectedFloorName);
            
            // Add filtered rooms to dropdown
            filteredRooms.forEach(room => {
                const option = document.createElement('option');
                option.value = room.name;
                option.textContent = `${room.name} (${room.room_number}) - ${room.floor_name}`;
                if (room.name === currentRoomValue) {
                    option.selected = true;
                }
                roomSelect.appendChild(option);
            });
        }

        // Add event listener for floor level changes
        floorSelect.addEventListener('change', function() {
            const selectedFloor = this.value;
            filterRoomsByFloor(selectedFloor);
        });

        // Initialize room dropdown based on current floor selection
        const currentFloor = floorSelect.value;
        const currentRoom = roomSelect.value;
        
        if (currentFloor) {
            filterRoomsByFloor(currentFloor);
        } else if (currentRoom) {
            // If no floor is selected but room is, show all rooms and select current room
            filterRoomsByFloor(null);
        }

        // Image removal functionality
        document.addEventListener('click', function(e) {
            // Handle multiple image removal
            if (e.target.closest('.remove-image-btn')) {
                const button = e.target.closest('.remove-image-btn');
                const imageId = button.getAttribute('data-image-id');
                const imageName = button.getAttribute('data-image-name');
                
                if (confirm(`Are you sure you want to remove "${imageName}"?`)) {
                    removeImage(imageId, button);
                }
            }
            
            // Handle legacy image removal
            if (e.target.closest('.remove-legacy-image-btn')) {
                const button = e.target.closest('.remove-legacy-image-btn');
                const itemId = button.getAttribute('data-item-id');
                
                if (confirm('Are you sure you want to remove the legacy image?')) {
                    removeLegacyImage(itemId, button);
                }
            }
        });

        function removeImage(imageId, button) {
            fetch(`/item/item-image/${imageId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Content-Type': 'application/json',
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove the image card from the DOM
                    button.closest('.col-md-3').remove();
                    
                    // Show success message
                    showAlert('Image removed successfully', 'success');
                    
                    // Check if no images left
                    const remainingImages = document.querySelectorAll('.remove-image-btn').length;
                    if (remainingImages === 0) {
                        location.reload(); // Reload to show "no images" state
                    }
                } else {
                    showAlert('Failed to remove image: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while removing the image', 'danger');
            });
        }

        function removeLegacyImage(itemId, button) {
            fetch(`/item/${itemId}/remove-legacy-image`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Content-Type': 'application/json',
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove the legacy image card from the DOM
                    button.closest('.col-md-3').remove();
                    
                    // Show success message
                    showAlert('Legacy image removed successfully', 'success');
                    
                    // Reload to show "no images" state
                    location.reload();
                } else {
                    showAlert('Failed to remove legacy image: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while removing the legacy image', 'danger');
            });
        }

        function showAlert(message, type) {
            // Create alert element
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            // Insert at the top of the form
            const form = document.querySelector('form');
            form.insertBefore(alertDiv, form.firstChild);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }

        // Multiple image upload handling
        const imageInput = document.getElementById('images');
        const imagePreview = document.getElementById('imagePreview');
        const imagePreviewContainer = document.getElementById('imagePreviewContainer');
        const maxFileSize = 10 * 1024 * 1024; // 10MB in bytes

        imageInput.addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            imagePreviewContainer.innerHTML = '';
            
            if (files.length === 0) {
                imagePreview.style.display = 'none';
                return;
            }

            // Validate file sizes
            const oversizedFiles = files.filter(file => file.size > maxFileSize);
            if (oversizedFiles.length > 0) {
                alert(`The following files exceed 10MB limit:\n${oversizedFiles.map(f => f.name).join('\n')}`);
                e.target.value = '';
                imagePreview.style.display = 'none';
                return;
            }

            // Validate file types
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            const invalidFiles = files.filter(file => !allowedTypes.includes(file.type));
            if (invalidFiles.length > 0) {
                alert(`The following files have invalid formats:\n${invalidFiles.map(f => f.name).join('\n')}\n\nSupported formats: JPG, PNG, GIF, WEBP`);
                e.target.value = '';
                imagePreview.style.display = 'none';
                return;
            }

            // Show previews
            imagePreview.style.display = 'block';
            
            files.forEach((file, index) => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const col = document.createElement('div');
                    col.className = 'col-md-3 mb-2';
                    
                    const card = document.createElement('div');
                    card.className = 'card position-relative';
                    card.style.height = '150px';
                    
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'card-img-top';
                    img.style.height = '120px';
                    img.style.objectFit = 'cover';
                    
                    const cardBody = document.createElement('div');
                    cardBody.className = 'card-body p-2';
                    
                    const fileName = document.createElement('small');
                    fileName.className = 'text-muted';
                    fileName.textContent = file.name.length > 15 ? file.name.substring(0, 15) + '...' : file.name;
                    
                    const fileSize = document.createElement('small');
                    fileSize.className = 'text-muted d-block';
                    fileSize.textContent = formatFileSize(file.size);
                    
                    const removeBtn = document.createElement('button');
                    removeBtn.type = 'button';
                    removeBtn.className = 'btn btn-sm btn-danger position-absolute';
                    removeBtn.style.top = '5px';
                    removeBtn.style.right = '5px';
                    removeBtn.innerHTML = '×';
                    removeBtn.onclick = function() {
                        removeImageFromPreview(index);
                    };
                    
                    cardBody.appendChild(fileName);
                    cardBody.appendChild(fileSize);
                    card.appendChild(img);
                    card.appendChild(cardBody);
                    card.appendChild(removeBtn);
                    col.appendChild(card);
                    imagePreviewContainer.appendChild(col);
                };
                reader.readAsDataURL(file);
            });
        });

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function removeImageFromPreview(index) {
            const dt = new DataTransfer();
            const input = document.getElementById('images');
            const files = Array.from(input.files);
            
            files.forEach((file, i) => {
                if (i !== index) {
                    dt.items.add(file);
                }
            });
            
            input.files = dt.files;
            
            // Trigger change event to update preview
            input.dispatchEvent(new Event('change'));
        }
    });
</script>
@endpush
@endsection

