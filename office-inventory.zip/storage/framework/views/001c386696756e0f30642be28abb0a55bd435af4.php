

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-decoration-underline mb-4">Add Purchase</h1>
    <?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('purchase.store')); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
            <div class="col-md-3">
                <label for="supplier_id" class="form-label">Supplier <span class="text-danger">*</span></label>
                <div class="input-group">
                <select name="supplier_id" id="supplier_id" class="form-select <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">-- Select Supplier --</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>" <?php echo e(old('supplier_id') == $supplier->id ? 'selected' : ''); ?>><?php echo e($supplier->name ?? 'No Name'); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                    <button type="button" class="btn btn-outline-primary" id="addSupplierBtn" data-bs-toggle="modal" data-bs-target="#addSupplierModal">
                        <i class="fas fa-plus"></i> Add New
                    </button>
                </div>
                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3">
                <label for="invoice_number" class="form-label">Invoice Number</label>
                <input type="text" name="invoice_number" id="invoice_number" class="form-control <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('invoice_number')); ?>">
                <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3">
                <label for="purchase_date" class="form-label">Purchase Date <span class="text-danger">*</span></label>
                <input type="date" name="purchase_date" id="purchase_date" class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('purchase_date')); ?>" required>
                <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-3">
                <label for="department_id" class="form-label">Department <span class="text-danger">*</span></label>
                <select name="department_id" id="department_id" class="form-select <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">-- Select Department --</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id') == $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?> (Level <?php echo e($department->location); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="purchased_by" class="form-label">Purchased By <span class="text-danger">*</span></label>
                <div class="input-group">
                <select name="purchased_by" id="purchased_by" class="form-select <?php $__errorArgs = ['purchased_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">-- Select User --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e(old('purchased_by') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                    <button type="button" class="btn btn-outline-primary" id="addUserPurchasedBtn" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="fas fa-plus"></i> Add New
                    </button>
                </div>
                <?php $__errorArgs = ['purchased_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="received_by" class="form-label">Received By <span class="text-danger">*</span></label>
                <div class="input-group">
                <select name="received_by" id="received_by" class="form-select <?php $__errorArgs = ['received_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">-- Select User --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e(old('received_by') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                    <button type="button" class="btn btn-outline-primary" id="addUserReceivedBtn" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="fas fa-plus"></i> Add New
                    </button>
                </div>
                <?php $__errorArgs = ['received_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="invoice_images" class="form-label">Invoice Images (webp/jpeg/png/pdf) - Multiple files allowed</label>
                <input type="file" name="invoice_images[]" id="invoice_images" class="form-control" accept="image/webp, image/jpeg, image/png, application/pdf" multiple>
                <small class="form-text text-muted">You can select multiple files (max 10 files, 4MB each)</small>
                <?php $__errorArgs = ['invoice_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['invoice_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="total_value" class="form-label">Total Value (auto-calculated)</label>
                <input type="text" name="total_value" id="total_value" class="form-control" readonly>
            </div>
        </div>

        <h4 class="mt-4">Purchased Items</h4>
        <table class="table table-bordered align-middle" id="items-table">
            <thead>
                <tr>
                    <th>Item Name <span class="text-danger">*</span></th>
                    <th>Type/Model</th>
                    <th>Quantity <span class="text-danger">*</span></th>
                    <th>Unit Price <span class="text-danger">*</span></th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="text" name="items[0][item_name]" class="form-control" required></td>
                    <td><input type="text" name="items[0][item_type]" class="form-control"></td>
                    <td><input type="number" name="items[0][quantity]" class="form-control item-qty" min="1" required></td>
                    <td><input type="number" name="items[0][unit_price]" class="form-control item-price" min="0" step="0.01" required></td>
                    <td><input type="text" class="form-control item-subtotal" readonly></td>
                    <td><button type="button" class="btn btn-danger btn-remove-row">Remove</button></td>
                </tr>
            </tbody>
        </table>
        <button type="button" class="btn btn-secondary mb-3" id="add-row">Add Item</button>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg" id="submit-btn">
                <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                <span class="btn-text">Save Purchase</span>
            </button>
            <div class="text-center">
                <small class="text-muted">All items will be automatically added to inventory</small>
            </div>
        </div>
    </form>
</div>

<!-- Add Supplier Modal -->
<div class="modal fade" id="addSupplierModal" tabindex="-1" aria-labelledby="addSupplierModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-success text-white border-0">
                <h5 class="modal-title fw-bold text-white" id="addSupplierModalLabel">
                    <i class="fas fa-plus-circle me-2"></i>
                    Add New Supplier
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addSupplierForm" onsubmit="return false;">
                <div class="modal-body">
                    <div id="supplierModalAlert" class="alert" style="display: none;"></div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_name" class="form-label">Brand Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="modal_supplier_name" name="name" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_incharge_name" class="form-label">Person in Charge</label>
                                <input type="text" class="form-control" id="modal_supplier_incharge_name" name="incharge_name">
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_contact" class="form-label">Contact Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="modal_supplier_contact" name="contact_number" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="modal_supplier_email" name="email">
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="modal_supplier_address" class="form-label">Address</label>
                        <textarea class="form-control" id="modal_supplier_address" name="address" rows="2"></textarea>
                        <div class="invalid-feedback"></div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_tax" class="form-label">Tax Number</label>
                                <input type="text" class="form-control" id="modal_supplier_tax" name="tax_number">
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_supplier_payment" class="form-label">Payment Terms</label>
                                <input type="text" class="form-control" id="modal_supplier_payment" name="payment_terms">
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="modal_supplier_notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="modal_supplier_notes" name="notes" rows="2"></textarea>
                        <div class="invalid-feedback"></div>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>
                        Cancel
                    </button>
                    <button type="button" class="btn btn-success" id="saveSupplierBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        <span class="btn-text">Add Supplier</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white border-0">
                <h5 class="modal-title fw-bold text-white" id="addUserModalLabel">
                    <i class="fas fa-user-plus me-2"></i>
                    Add New User
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addUserForm" onsubmit="return false;">
                <div class="modal-body">
                    <div id="userModalAlert" class="alert" style="display: none;"></div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_user_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="modal_user_name" name="name" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="modal_user_email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="modal_user_email" name="email" required>
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="modal_user_designation_id" class="form-label">Designation <span class="text-danger">*</span></label>
                        <select class="form-select" id="modal_user_designation_id" name="designation_id" required>
                            <option value="">-- Select Designation --</option>
                            <?php $__currentLoopData = \App\Models\Designation::with('department')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->name); ?> (<?php echo e($designation->department->name); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback"></div>
                    </div>
                    
                    <!-- Hidden fields for auto-generated values -->
                    <input type="hidden" id="modal_user_password" name="password" value="">
                    <input type="hidden" id="modal_user_role" name="role" value="employee">
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>
                        Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="saveUserBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        <span class="btn-text">Add User</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
// Auto-fill received_by with purchased_by when purchased_by changes
document.getElementById('purchased_by').addEventListener('change', function() {
    const purchasedBy = this.value;
    const receivedBy = document.getElementById('received_by');
    if (purchasedBy && !receivedBy.value) {
        receivedBy.value = purchasedBy;
    }
});

// Calculate subtotals and total
function calculateSubtotals() {
    let total = 0;
    document.querySelectorAll('#items-table tbody tr').forEach(function(row) {
        const quantity = parseFloat(row.querySelector('.item-qty').value) || 0;
        const price = parseFloat(row.querySelector('.item-price').value) || 0;
        const subtotal = quantity * price;
        row.querySelector('.item-subtotal').value = subtotal.toFixed(2);
        total += subtotal;
    });
    document.getElementById('total_value').value = total.toFixed(2);
}

// Add event listeners for quantity and price changes
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('item-qty') || e.target.classList.contains('item-price')) {
        calculateSubtotals();
    }
});

// Add row functionality
document.getElementById('add-row').addEventListener('click', function() {
    const tbody = document.querySelector('#items-table tbody');
    const rowCount = tbody.children.length;
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td><input type="text" name="items[${rowCount}][item_name]" class="form-control" required></td>
        <td><input type="text" name="items[${rowCount}][item_type]" class="form-control"></td>
        <td><input type="number" name="items[${rowCount}][quantity]" class="form-control item-qty" min="1" required></td>
        <td><input type="number" name="items[${rowCount}][unit_price]" class="form-control item-price" min="0" step="0.01" required></td>
        <td><input type="text" class="form-control item-subtotal" readonly></td>
        <td><button type="button" class="btn btn-danger btn-remove-row">Remove</button></td>
    `;
    tbody.appendChild(newRow);
    
    // Add event listeners to new row
    newRow.querySelector('.item-qty').addEventListener('input', calculateSubtotals);
    newRow.querySelector('.item-price').addEventListener('input', calculateSubtotals);
    newRow.querySelector('.btn-remove-row').addEventListener('click', function() {
        newRow.remove();
        calculateSubtotals();
    });
});

// Remove row functionality
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-remove-row')) {
        e.target.closest('tr').remove();
        calculateSubtotals();
    }
});

// Initialize calculations
calculateSubtotals();

// Form submission loading state
document.querySelector('form').addEventListener('submit', function() {
    const submitBtn = document.getElementById('submit-btn');
    const spinner = submitBtn.querySelector('.spinner-border');
    const btnText = submitBtn.querySelector('.btn-text');
    
    submitBtn.disabled = true;
    spinner.classList.remove('d-none');
    btnText.textContent = 'Creating Purchase...';
});

    // Supplier Modal Handling
    const supplierModal = document.getElementById('addSupplierModal');
    const addSupplierForm = document.getElementById('addSupplierForm');
    const saveSupplierBtn = document.getElementById('saveSupplierBtn');
    const supplierModalAlert = document.getElementById('supplierModalAlert');

    // Reset modal form when modal is closed
    supplierModal.addEventListener('hidden.bs.modal', function() {
        addSupplierForm.reset();
        addSupplierForm.querySelectorAll('.is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });
        addSupplierForm.querySelectorAll('.invalid-feedback').forEach(feedback => {
            feedback.textContent = '';
        });
        supplierModalAlert.style.display = 'none';
    });

    // Handle supplier form submission
    function handleSupplierSubmit() {
        // Show loading state
        const spinner = saveSupplierBtn.querySelector('.spinner-border');
        const btnText = saveSupplierBtn.querySelector('.btn-text');
        spinner.classList.remove('d-none');
        btnText.textContent = 'Adding...';
        saveSupplierBtn.disabled = true;

        // Clear previous errors
        addSupplierForm.querySelectorAll('.is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });
        addSupplierForm.querySelectorAll('.invalid-feedback').forEach(feedback => {
            feedback.textContent = '';
        });
        supplierModalAlert.style.display = 'none';

        // Prepare form data
        const formData = new FormData(addSupplierForm);
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

        // Submit via AJAX
        fetch('<?php echo e(route("supplier.storeAjax")); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add new supplier to dropdown
                const supplierSelect = document.getElementById('supplier_id');
                const newOption = document.createElement('option');
                newOption.value = data.supplier.id;
                newOption.textContent = data.supplier.name;
                supplierSelect.appendChild(newOption);
                
                // Select the new supplier
                supplierSelect.value = data.supplier.id;
                
                // Show success message
                supplierModalAlert.className = 'alert alert-success';
                supplierModalAlert.textContent = 'Supplier added successfully!';
                supplierModalAlert.style.display = 'block';
                
                // Close modal after a short delay
                setTimeout(() => {
                    const modal = bootstrap.Modal.getInstance(supplierModal);
                    modal.hide();
                }, 1500);
            } else {
                // Handle validation errors
                if (data.errors) {
                    Object.keys(data.errors).forEach(field => {
                        const input = addSupplierForm.querySelector(`[name="${field}"]`);
                        if (input) {
                            input.classList.add('is-invalid');
                            const feedback = input.parentElement.querySelector('.invalid-feedback');
                            if (feedback) {
                                feedback.textContent = data.errors[field][0];
                            }
                        }
                    });
                } else {
                    // Show general error
                    supplierModalAlert.className = 'alert alert-danger';
                    supplierModalAlert.textContent = data.message || 'An error occurred while adding the supplier.';
                    supplierModalAlert.style.display = 'block';
                }
            }
        })
        .catch(error => {
            supplierModalAlert.className = 'alert alert-danger';
            supplierModalAlert.textContent = 'An error occurred while adding the supplier: ' + error.message;
            supplierModalAlert.style.display = 'block';
        })
        .finally(() => {
            // Reset loading state
            spinner.classList.add('d-none');
            btnText.textContent = 'Add Supplier';
            saveSupplierBtn.disabled = false;
        });
    }

    // Handle supplier form submission
    addSupplierForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        handleSupplierSubmit();
    });

    // Handle supplier button click
    saveSupplierBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        handleSupplierSubmit();
    });

    // User Modal Handling
    const userModal = document.getElementById('addUserModal');
    const addUserForm = document.getElementById('addUserForm');
    const saveUserBtn = document.getElementById('saveUserBtn');
    const userModalAlert = document.getElementById('userModalAlert');

    // Auto-generate password and set role when modal is shown
    userModal.addEventListener('show.bs.modal', function() {
        // Generate a random password
        const password = generateRandomPassword();
        document.getElementById('modal_user_password').value = password;
        
        // Set role to employee
        document.getElementById('modal_user_role').value = 'employee';
    });

    // Function to generate random password
    function generateRandomPassword() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < 12; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }

    // Reset modal form when modal is closed
    userModal.addEventListener('hidden.bs.modal', function() {
        addUserForm.reset();
        addUserForm.querySelectorAll('.is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });
        addUserForm.querySelectorAll('.invalid-feedback').forEach(feedback => {
            feedback.textContent = '';
        });
        userModalAlert.style.display = 'none';
    });

    // Handle user form submission
    function handleUserSubmit() {
        // Show loading state
        const spinner = saveUserBtn.querySelector('.spinner-border');
        const btnText = saveUserBtn.querySelector('.btn-text');
        spinner.classList.remove('d-none');
        btnText.textContent = 'Adding...';
        saveUserBtn.disabled = true;

        // Clear previous errors
        addUserForm.querySelectorAll('.is-invalid').forEach(field => {
            field.classList.remove('is-invalid');
        });
        addUserForm.querySelectorAll('.invalid-feedback').forEach(feedback => {
            feedback.textContent = '';
        });
        userModalAlert.style.display = 'none';

        // Prepare form data
        const formData = new FormData(addUserForm);
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

        // Submit via AJAX
        fetch('<?php echo e(route("user-management.storeAjax")); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add new user to all user dropdowns
                const newOption = document.createElement('option');
                newOption.value = data.user.id;
                newOption.textContent = data.user.name + ' (' + data.user.email + ')';
                
                const purchasedBySelect = document.getElementById('purchased_by');
                const receivedBySelect = document.getElementById('received_by');
                
                purchasedBySelect.appendChild(newOption.cloneNode(true));
                receivedBySelect.appendChild(newOption.cloneNode(true));
                
                // Select the new user in the current dropdown
                const currentSelect = document.querySelector('[data-bs-target="#addUserModal"]:focus')?.closest('.input-group')?.querySelector('select');
                if (currentSelect) {
                    currentSelect.value = data.user.id;
                }
                
                // Show success message
                userModalAlert.className = 'alert alert-success';
                userModalAlert.textContent = 'User added successfully!';
                userModalAlert.style.display = 'block';
                
                // Close modal after a short delay
                setTimeout(() => {
                    const modal = bootstrap.Modal.getInstance(userModal);
                    modal.hide();
                }, 1500);
            } else {
                // Handle validation errors
                if (data.errors) {
                    Object.keys(data.errors).forEach(field => {
                        const input = addUserForm.querySelector(`[name="${field}"]`);
                        if (input) {
                            input.classList.add('is-invalid');
                            const feedback = input.parentElement.querySelector('.invalid-feedback');
                            if (feedback) {
                                feedback.textContent = data.errors[field][0];
                            }
                        }
                    });
                } else {
                    // Show general error
                    userModalAlert.className = 'alert alert-danger';
                    userModalAlert.textContent = data.message || 'An error occurred while adding the user.';
                    userModalAlert.style.display = 'block';
                }
            }
        })
        .catch(error => {
            userModalAlert.className = 'alert alert-danger';
            userModalAlert.textContent = 'An error occurred while adding the user: ' + error.message;
            userModalAlert.style.display = 'block';
        })
        .finally(() => {
            // Reset loading state
            spinner.classList.add('d-none');
            btnText.textContent = 'Add User';
            saveUserBtn.disabled = false;
        });
    }

    // Handle user form submission
    addUserForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        handleUserSubmit();
    });

    // Handle user button click
    saveUserBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        handleUserSubmit();
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/purchase/add.blade.php ENDPATH**/ ?>