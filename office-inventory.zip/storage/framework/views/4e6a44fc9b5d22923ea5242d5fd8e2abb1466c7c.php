

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-decoration-underline mb-4">Purchase Details</h1>
    <a href="<?php echo e(route('purchase.index')); ?>" class="btn btn-secondary mb-3">Back to Purchases</a>
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">
                Purchase: <?php echo e($purchase->purchase_number ?? 'PUR-' . $purchase->id); ?>

                <span class="badge bg-success ms-2">Created</span>
            </h5>
            <div class="row">
                <div class="col-md-6">
                    <p class="card-text mb-1"><strong>Supplier:</strong> <?php echo e($purchase->supplier ? $purchase->supplier->name : '-'); ?></p>
                    <p class="card-text mb-1"><strong>Invoice Number:</strong> <?php echo e($purchase->invoice_number); ?></p>
                    <p class="card-text mb-1"><strong>Purchase Date:</strong> <?php echo e($purchase->purchase_date->format('d-M-Y')); ?></p>
                    <p class="card-text mb-1"><strong>Total Value:</strong> <span class="text-success fw-bold">$<?php echo e(number_format($purchase->total_value, 2)); ?></span></p>
                </div>
                <div class="col-md-6">
                    <p class="card-text mb-1"><strong>Department:</strong> <?php echo e($purchase->department ? $purchase->department->name . ' (Level ' . $purchase->department->location . ')' : '-'); ?></p>
                    <p class="card-text mb-1"><strong>Purchased By:</strong> <?php echo e($purchase->purchasedBy ? $purchase->purchasedBy->name . ' (' . $purchase->purchasedBy->email . ')' : '-'); ?></p>
                    <p class="card-text mb-1"><strong>Received By:</strong> <?php echo e($purchase->receivedBy ? $purchase->receivedBy->name . ' (' . $purchase->receivedBy->email . ')' : '-'); ?></p>
                    <?php if($purchase->invoice_image): ?>
                        <p class="card-text mb-1"><strong>Main Invoice Image:</strong><br>
                            <a href="<?php echo e(asset('storage/' . $purchase->invoice_image)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View Main Invoice</a>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <h4>Purchased Items</h4>
    <table class="table table-bordered align-middle">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Type/Model</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->item_name); ?></td>
                <td><?php echo e($item->item_type); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td><?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td><?php echo e(number_format($item->quantity * $item->unit_price, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if($purchase->images->count() > 0): ?>
        <div class="mt-4">
            <h4>Invoice Images (<?php echo e($purchase->images->count()); ?> images)</h4>
            <div class="row">
                <?php $__currentLoopData = $purchase->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="card">
                            <img src="<?php echo e($image->image_url); ?>" class="card-img-top" style="height: 200px; object-fit: cover;" alt="Invoice Image" data-bs-toggle="modal" data-bs-target="#imageModal<?php echo e($image->id); ?>">
                            <div class="card-body p-2">
                                <h6 class="card-title text-truncate" title="<?php echo e($image->original_name); ?>"><?php echo e($image->original_name); ?></h6>
                                <small class="text-muted"><?php echo e($image->file_size_human); ?></small>
                                <div class="mt-2">
                                    <a href="<?php echo e($image->image_url); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View Full Size</a>
                                    <form method="POST" action="<?php echo e(route('purchase.deleteImage', [$purchase->id, $image->id])); ?>" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to delete this image?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Image Modal -->
                    <div class="modal fade" id="imageModal<?php echo e($image->id); ?>" tabindex="-1" aria-labelledby="imageModalLabel<?php echo e($image->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="imageModalLabel<?php echo e($image->id); ?>"><?php echo e($image->original_name); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body text-center">
                                    <img src="<?php echo e($image->image_url); ?>" class="img-fluid" alt="Invoice Image">
                                </div>
                                <div class="modal-footer">
                                    <a href="<?php echo e($image->image_url); ?>" target="_blank" class="btn btn-primary">View Full Size</a>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/purchase/show.blade.php ENDPATH**/ ?>