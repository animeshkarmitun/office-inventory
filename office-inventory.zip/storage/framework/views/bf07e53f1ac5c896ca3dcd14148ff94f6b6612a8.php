<table class="table">
    <thead class="table-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Serial Number</th>
            <th scope="col">Asset Tag</th>
            <th scope="col">Barcode</th>
            <th scope="col">RFID Tag</th>
            <th scope="col">Location</th>
            <th scope="col">Assigned User</th>
            <th scope="col">Condition</th>
            <th scope="col">Asset Type</th>
            <th scope="col">Value</th>
            <th scope="col">Annual Depreciation</th>
            <th scope="col">Book Value</th>
            <th scope="col">Status</th>
            <th scope="col">Approval</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><a href="<?php echo e(route('item.history', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
            <td><?php echo e($item->serial_number); ?></td>
            <td><?php echo e($item->asset_tag ?? 'N/A'); ?></td>
            <td><?php echo e($item->barcode ?? 'N/A'); ?></td>
            <td><?php echo e($item->rfid_tag ?? 'N/A'); ?></td>
            <td>
                <?php echo e($item->floor_level); ?> - <?php echo e($item->room_number); ?>

                <?php if($item->location): ?>
                    <br><small><?php echo e($item->location); ?></small>
                <?php endif; ?>
            </td>
            <td><?php echo e($item->assignedUser->name ?? 'N/A'); ?></td>
            <td><?php echo e($item->condition ?? 'N/A'); ?></td>
            <td><?php echo e(ucfirst($item->asset_type)); ?></td>
            <td><?php echo e($item->value ? number_format($item->value, 2) : 'N/A'); ?></td>
            <td><?php echo e($item->annualDepreciation() !== null ? number_format($item->annualDepreciation(), 2) : 'N/A'); ?></td>
            <td><?php echo e($item->currentBookValue() !== null ? number_format($item->currentBookValue(), 2) : 'N/A'); ?></td>
            <td>
                <?php if($item->status === 'pending'): ?>
                    <span class="badge bg-warning" data-bs-toggle="tooltip" title="Pending approval">Pending</span>
                <?php elseif($item->status === 'approved'): ?>
                    <span class="badge bg-success" data-bs-toggle="tooltip" title="Approved by: <?php echo e($item->approvedBy ? $item->approvedBy->name : 'N/A'); ?>&#10;<?php echo e($item->approved_at ? $item->approved_at->format('Y-m-d H:i') : ''); ?>">Approved</span>
                <?php else: ?>
                    <span class="badge bg-secondary"><?php echo e(ucfirst($item->status)); ?></span>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <?php if($item->is_approved): ?>
                    <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Approved</span>
                    <br>
                    <small>By: <?php echo e($item->approvedBy ? $item->approvedBy->name : 'N/A'); ?></small>
                    <br>
                    <small><?php echo e($item->approved_at->format('Y-m-d H:i')); ?></small>
                <?php else: ?>
                    <span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split me-1"></i>Pending</span>
                <?php endif; ?>
            </td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="actionsDropdown<?php echo e($item->id); ?>" aria-expanded="false">
                        Actions
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="actionsDropdown<?php echo e($item->id); ?>">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('item.showEdit', ['id' => $item->id])); ?>">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item text-danger" href="<?php echo e(route('item.destroy', ['id' => $item->id])); ?>" onclick="return confirm('Are you sure?');">
                                <i class="bi bi-trash"></i> Delete
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('asset.movement.history', ['id' => $item->id])); ?>">
                                <i class="bi bi-clock-history"></i> Movement History
                            </a>
                        </li>
                        <?php if(Auth::user()->is_admin): ?>
                            <?php if(!$item->is_approved): ?>
                                <li>
                                    <form action="<?php echo e(route('item.approve', ['id' => $item->id])); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-success">
                                            <i class="bi bi-check-circle"></i> Approve
                                        </button>
                                    </form>
                                </li>
                            <?php else: ?>
                                <li>
                                    <form action="#" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-warning">
                                            <i class="bi bi-x-circle"></i> Reject
                                        </button>
                                    </form>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php if(method_exists($items, 'links')): ?>
    <div class="pagination-wrapper">
        <div class="pagination-info">
            Showing <?php echo e($items->firstItem() ?? 0); ?> to <?php echo e($items->lastItem() ?? 0); ?> of <?php echo e($items->total()); ?> results
        </div>
        <div class="d-flex justify-content-center">
            <?php echo $items->links(); ?>

        </div>
    </div>
<?php endif; ?> <?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/item/partials/table.blade.php ENDPATH**/ ?>