

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-decoration-underline mb-4">Purchases</h1>
    <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-primary mb-3">Add Purchase</a>
    <form method="GET" action="<?php echo e(route('purchase.index')); ?>" class="mb-3 d-flex" style="max-width: 400px;">
        <input type="text" name="search" class="form-control me-2" placeholder="Search by supplier, invoice, or date..." value="<?php echo e(request('search')); ?>">
        <button type="submit" class="btn btn-outline-primary">Search</button>
    </form>
    <?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table table-bordered table-striped align-middle">
        <thead>
            <tr>
                <th>Purchase #</th>
                <th>Supplier</th>
                <th>Invoice Number</th>
                <th>Date</th>
                <th>Department</th>
                <th>Total Value</th>
                <th>Images</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($purchase->purchase_number ?? 'PUR-' . $purchase->id); ?></td>
                <td>
                    <?php if($purchase->supplier): ?>
                        <a href="<?php echo e(route('supplier.purchases', $purchase->supplier->id)); ?>"><?php echo e($purchase->supplier->name); ?></a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td><?php echo e($purchase->invoice_number); ?></td>
                <td><?php echo e($purchase->purchase_date ? $purchase->purchase_date->format('d-M-Y') : '-'); ?></td>
                <td><?php echo e($purchase->department ? $purchase->department->name : '-'); ?></td>
                <td><?php echo e(number_format($purchase->total_value, 2)); ?></td>
                <td>
                    <?php if($purchase->images->count() > 0): ?>
                        <span class="badge bg-info"><?php echo e($purchase->images->count()); ?> image(s)</span>
                    <?php else: ?>
                        <span class="text-muted">No images</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('purchase.show', $purchase->id)); ?>" class="btn btn-info btn-sm">View</a>
                    <a href="<?php echo e(route('purchase.edit', $purchase->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('purchase.destroy', $purchase->id)); ?>" method="POST" style="display:inline-block" class="delete-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" class="btn btn-danger btn-sm btn-delete-modal" data-id="<?php echo e($purchase->id); ?>">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this purchase?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let formToDelete = null;
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    document.querySelectorAll('.btn-delete-modal').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            formToDelete = btn.closest('form');
            deleteModal.show();
        });
    });
    document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
        if (formToDelete) {
            formToDelete.submit();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/purchase/index.blade.php ENDPATH**/ ?>