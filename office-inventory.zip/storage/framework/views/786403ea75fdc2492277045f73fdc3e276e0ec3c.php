

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Purchases from <span class="fw-bold"><?php echo e($supplier->name); ?></span></h2>
    <div class="card">
        <div class="card-body">
            <?php if($purchases->isEmpty()): ?>
                <p>No purchases found for this supplier.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Invoice Number</th>
                                <th>Date</th>
                                <th>Total Value</th>
                                <th>Supplied Items</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($purchase->invoice_number); ?></td>
                                <td><?php echo e($purchase->purchase_date ? $purchase->purchase_date->format('d-M-Y') : '-'); ?></td>
                                <td><?php echo e(number_format($purchase->total_value, 2)); ?></td>
                                <td>
                                    <?php if($purchase->items->isEmpty()): ?>
                                        <em>No items</em>
                                    <?php else: ?>
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($item->item_name); ?> (x<?php echo e($item->quantity); ?>) <?php if($item->unit_price): ?> - <?php echo e(number_format($item->unit_price, 2)); ?> each <?php endif; ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <a href="<?php echo e(route('purchase.index')); ?>" class="btn btn-secondary mt-4">Back to Purchases</a>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/supplier/purchases.blade.php ENDPATH**/ ?>