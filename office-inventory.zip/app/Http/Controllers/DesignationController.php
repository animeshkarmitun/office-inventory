<?php

namespace App\Http\Controllers;

use App\Models\Designation;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DesignationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:super_admin,admin');
    }

    public function index(Request $request)
    {
        $query = Designation::with('department');
        
        // Filter by department if specified
        if ($request->has('department') && $request->department) {
            $query->where('department_id', $request->department);
        }
        
        $designations = $query->orderBy('name')->get();
        $departments = Department::orderBy('name')->get();
        
        return view('pages.designation.index', compact('designations', 'departments'));
    }

    public function create()
    {
        $departments = Department::orderBy('name')->get();
        return view('pages.designation.create', compact('departments'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'department_id' => 'required|exists:departments,id',
        ]);

        Designation::create([
            'name' => $request->name,
            'department_id' => $request->department_id,
        ]);

        return redirect()->route('designation.index')
            ->with(['message' => 'Designation created successfully', 'alert' => 'alert-success']);
    }

    public function show(Designation $designation)
    {
        $designation->load('department');
        return view('pages.designation.show', compact('designation'));
    }

    public function edit(Designation $designation)
    {
        $departments = Department::orderBy('name')->get();
        return view('pages.designation.edit', compact('designation', 'departments'));
    }

    public function update(Request $request, Designation $designation)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'department_id' => 'required|exists:departments,id',
        ]);

        $designation->update([
            'name' => $request->name,
            'department_id' => $request->department_id,
        ]);

        return redirect()->route('designation.index')
            ->with(['message' => 'Designation updated successfully', 'alert' => 'alert-success']);
    }

    public function destroy(Designation $designation)
    {
        $designation->delete();

        return redirect()->route('designation.index')
            ->with(['message' => 'Designation deleted successfully', 'alert' => 'alert-success']);
    }
}