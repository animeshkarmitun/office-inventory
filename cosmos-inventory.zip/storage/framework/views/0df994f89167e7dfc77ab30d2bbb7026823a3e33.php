<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-decoration-underline">List of Suppliers</h1>
        <a href="<?php echo e(route('supplier.showAdd')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add new supplier
        </a>
    </div>
    <form method="GET" action="" class="mb-4">
        <div class="input-group input-group-lg">
            <input type="text" name="search" class="form-control" placeholder="Search suppliers..." value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </div>
    </form>
    
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Brand Name</th>
                    <th scope="col">Person in charge</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($supplier->id); ?></th>
                    <td><?php echo e($supplier->name); ?></td>
                    <td><?php echo e($supplier->incharge_name); ?></td>
                    <td><?php echo e($supplier->contact_number); ?></td>
                    <td><?php echo e($supplier->email ?? 'N/A'); ?></td>
                    <td><?php echo e($supplier->address ?? 'N/A'); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <a href="<?php echo e(route('supplier.showEdit', ['id'=>$supplier->id])); ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo e(route('supplier.destroy', ['id'=>$supplier->id])); ?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this supplier?')">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\office-inventory\resources\views/pages/supplier/index.blade.php ENDPATH**/ ?>