<?php if(session()->has('message')): ?>
<div class="alert <?php echo e(session('alert')); ?> alert-dismissible fade show" role="alert">
    <div class="d-flex align-items-start">
        <div class="flex-grow-1">
            <h6 class="alert-heading mb-2">
                <?php if(session('alert') == 'alert-success'): ?>
                    ✅ <?php echo e(session('message')); ?>

                <?php elseif(session('alert') == 'alert-danger'): ?>
                    ❌ <?php echo e(session('message')); ?>

                <?php elseif(session('alert') == 'alert-warning'): ?>
                    ⚠️ <?php echo e(session('message')); ?>

                <?php else: ?>
                    ℹ️ <?php echo e(session('message')); ?>

                <?php endif; ?>
            </h6>
            
            <?php if(session()->has('details') && session('alert') == 'alert-success'): ?>
                <div class="mt-2">
                    <small class="text-muted">
                        <strong>Purchase Details:</strong><br>
                        • Items Added: <?php echo e(session('details.items_count') ?? 0); ?><br>
                        • Total Value: ৳<?php echo e(session('details.total_value') ?? '0.00'); ?><br>
                        • Department: <?php echo e(session('details.department') ?? 'Unknown'); ?>

                    </small>
                </div>
            <?php endif; ?>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <div class="d-flex align-items-start">
        <div class="flex-grow-1">
            <h6 class="alert-heading mb-2">❌ Please fix the following errors:</h6>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\office-inventory\resources\views/inc/alert.blade.php ENDPATH**/ ?>