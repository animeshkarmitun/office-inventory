@extends('layouts.app')

@section('content')
    <h1>Employee Dashboard</h1>
    <p>Welcome to the employee dashboard. Here you can view your assigned assets and request new ones.</p>
@endsection 