<footer class="py-3 my-4 mt-auto">
    <p class="text-center border-top text-muted pt-3">© 2021 Inventory</p>
</footer>
