@extends('layouts.app')

@section('content')
    <h1>Welcome to the Dashboard</h1>
    <p>This is the default dashboard page. Please use the navigation to access your role-specific dashboard.</p>
@endsection 